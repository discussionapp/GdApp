package com.anshu.www.gdapp.modal;


public class AdminHelper {
    String Topic_name;

    public AdminHelper() {
    }

    public AdminHelper(String topic_name) {
        Topic_name = topic_name;
    }

    public String getTopic_name() {
        return Topic_name;
    }

    public void setTopic_name(String topic_name) {
        Topic_name = topic_name;
    }
}
