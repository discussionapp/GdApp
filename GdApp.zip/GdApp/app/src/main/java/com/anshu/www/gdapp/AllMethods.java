package com.anshu.www.gdapp;

class AllMethods {

    public  static  String name="";
}
